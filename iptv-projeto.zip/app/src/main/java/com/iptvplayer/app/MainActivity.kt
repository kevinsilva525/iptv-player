package com.iptvplayer.app

import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.doAfterTextChanged
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    companion object {
        // Muitos servidores IPTV só aceitam players conhecidos.
        const val UA = "VLC/3.0.20 LibVLC/3.0.20"
        val MODES = listOf("auto", "hls", "prog")
        const val TIMEOUT_MS = 20000L
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var exo: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var playerBox: FrameLayout
    private lateinit var listPanel: View
    private lateinit var statusTv: TextView
    private lateinit var nowTv: TextView
    private lateinit var countTv: TextView
    private lateinit var searchEt: EditText
    private lateinit var groupSp: Spinner
    private lateinit var favCb: CheckBox
    private lateinit var adapter: ChannelAdapter

    private val handler = Handler(Looper.getMainLooper())
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private var all: List<Channel> = emptyList()
    private var groups: List<String> = emptyList()
    private var selectedGroup: String? = null
    private var favs: MutableSet<String> = HashSet()
    private var current: Channel? = null
    private var fullscreen = false

    private var attempt = 0
    private var wasReady = false
    private var retries = 0
    private var token = 0

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) readFile(uri)
    }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_BUFFERING -> showStatus("Carregando...")
                Player.STATE_READY -> {
                    wasReady = true
                    hideStatus()
                }
                else -> {}
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            if (wasReady && retries < 3) {
                retries++
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    exo.seekToDefaultPosition()
                }
                exo.prepare()
                return
            }
            nextAttempt(error.errorCodeName)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefs = getSharedPreferences("iptv", Context.MODE_PRIVATE)
        favs = HashSet(prefs.getStringSet("favs", emptySet()) ?: emptySet())

        playerView = findViewById(R.id.playerView)
        playerBox = findViewById(R.id.playerBox)
        listPanel = findViewById(R.id.listPanel)
        statusTv = findViewById(R.id.status)
        nowTv = findViewById(R.id.now)
        countTv = findViewById(R.id.count)
        searchEt = findViewById(R.id.search)
        groupSp = findViewById(R.id.groupSp)
        favCb = findViewById(R.id.favOnly)
        val rv: RecyclerView = findViewById(R.id.list)

        exo = ExoPlayer.Builder(this).build()
        exo.addListener(listener)
        playerView.player = exo

        adapter = ChannelAdapter(
            onClick = { play(it) },
            onLongClick = { toggleFav(it) },
            isFav = { favs.contains(it.key) },
            isCurrent = { current?.key == it.key }
        )
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        findViewById<Button>(R.id.btnPlaylist).setOnClickListener { showLoadDialog() }
        findViewById<Button>(R.id.btnRetry).setOnClickListener { current?.let { play(it) } }
        findViewById<View>(R.id.btnFs).setOnClickListener { toggleFullscreen() }

        searchEt.doAfterTextChanged { applyFilter() }
        favCb.setOnCheckedChangeListener { _, _ -> applyFilter() }
        groupSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                selectedGroup = if (pos <= 0 || pos > groups.size) null else groups[pos - 1]
                applyFilter()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (fullscreen) {
                    toggleFullscreen()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        // Reabre a última playlist salva
        val saved = File(filesDir, "playlist.m3u")
        if (saved.exists()) {
            Thread {
                val text = try { saved.readText() } catch (e: Exception) { "" }
                val list = M3u.parse(text)
                runOnUiThread { if (list.isNotEmpty()) setChannels(list) else showLoadDialog() }
            }.start()
        } else {
            showLoadDialog()
        }
    }

    // ---------- Playlist ----------

    private fun showLoadDialog() {
        val et = EditText(this)
        et.hint = "http://servidor/lista.m3u"
        et.setText(prefs.getString("url", ""))
        et.setSingleLine()
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(et, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        AlertDialog.Builder(this)
            .setTitle("Carregar playlist")
            .setView(box)
            .setPositiveButton("Carregar URL") { _, _ ->
                val u = et.text.toString().trim()
                if (u.isNotEmpty()) {
                    prefs.edit().putString("url", u).apply()
                    loadUrl(u)
                }
            }
            .setNeutralButton("Arquivo") { _, _ -> pickFile.launch(arrayOf("*/*")) }
            .setNegativeButton("Colar") { _, _ -> pasteClipboard() }
            .show()
    }

    private fun pasteClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim() ?: ""
        when {
            t.contains("#EXTINF") -> applyPlaylistText(t)
            t.startsWith("http", ignoreCase = true) && !t.contains('\n') -> {
                prefs.edit().putString("url", t).apply()
                loadUrl(t)
            }
            else -> Toast.makeText(this, "Nada de playlist na área de transferência", Toast.LENGTH_LONG).show()
        }
    }

    private fun readFile(uri: Uri) {
        showStatus("Lendo arquivo...")
        Thread {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                runOnUiThread { applyPlaylistText(text) }
            } catch (e: Exception) {
                runOnUiThread { showStatus("Erro ao ler arquivo: " + (e.message ?: e.javaClass.simpleName), true) }
            }
        }.start()
    }

    private fun loadUrl(url: String) {
        showStatus("Baixando playlist...")
        Thread {
            try {
                val req = Request.Builder().url(url).header("User-Agent", UA).build()
                client.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) throw RuntimeException("HTTP " + r.code)
                    val text = r.body?.string() ?: ""
                    runOnUiThread { applyPlaylistText(text) }
                }
            } catch (e: Exception) {
                runOnUiThread { showStatus("Erro ao baixar a playlist: " + (e.message ?: e.javaClass.simpleName), true) }
            }
        }.start()
    }

    private fun applyPlaylistText(text: String) {
        showStatus("Lendo canais...")
        Thread {
            val list = M3u.parse(text)
            if (list.isNotEmpty()) {
                try { File(filesDir, "playlist.m3u").writeText(text) } catch (e: Exception) { }
            }
            runOnUiThread {
                if (list.isEmpty()) {
                    showStatus("Nenhum canal encontrado nessa playlist.", true)
                } else {
                    setChannels(list)
                    showStatus(list.size.toString() + " canais carregados")
                    handler.postDelayed({ hideStatus() }, 2500)
                }
            }
        }.start()
    }

    private fun setChannels(list: List<Channel>) {
        all = list
        groups = list.map { it.group }.distinct().sorted()
        val items = ArrayList<String>()
        items.add("Todos os grupos")
        items.addAll(groups)
        selectedGroup = null
        groupSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        applyFilter()
    }

    private fun applyFilter() {
        val q = searchEt.text.toString().trim().lowercase()
        val g = selectedGroup
        val onlyFav = favCb.isChecked
        val filtered = all.filter {
            (g == null || it.group == g) &&
                (q.isEmpty() || it.name.lowercase().contains(q)) &&
                (!onlyFav || favs.contains(it.key))
        }
        adapter.submit(filtered)
        countTv.text = filtered.size.toString() + " canais"
    }

    private fun toggleFav(c: Channel) {
        if (favs.contains(c.key)) favs.remove(c.key) else favs.add(c.key)
        prefs.edit().putStringSet("favs", HashSet(favs)).apply()
        Toast.makeText(
            this,
            if (favs.contains(c.key)) "Adicionado aos favoritos" else "Removido dos favoritos",
            Toast.LENGTH_SHORT
        ).show()
        applyFilter()
    }

    // ---------- Reprodução ----------

    private fun play(c: Channel) {
        current = c
        attempt = 0
        wasReady = false
        retries = 0
        nowTv.text = c.name
        adapter.notifyDataSetChanged()
        startAttempt()
    }

    private fun startAttempt() {
        val c = current ?: return
        val mode = MODES[attempt]
        token++
        val myToken = token

        val factory = OkHttpDataSource.Factory(client).setUserAgent(c.userAgent ?: UA)
        if (c.headers.isNotEmpty()) factory.setDefaultRequestProperties(c.headers)

        val item = MediaItem.fromUri(c.url)
        val src: MediaSource = when (mode) {
            "hls" -> HlsMediaSource.Factory(factory).setAllowChunklessPreparation(true).createMediaSource(item)
            "prog" -> ProgressiveMediaSource.Factory(factory).createMediaSource(item)
            else -> DefaultMediaSourceFactory(factory).createMediaSource(item)
        }

        showStatus("Conectando...")
        exo.setMediaSource(src)
        exo.prepare()
        exo.playWhenReady = true

        handler.postDelayed({
            if (myToken == token && !wasReady) nextAttempt("tempo esgotado")
        }, TIMEOUT_MS)
    }

    private fun nextAttempt(reason: String) {
        if (attempt < MODES.size - 1) {
            attempt++
            startAttempt()
        } else {
            token++
            exo.stop()
            showStatus("Não foi possível reproduzir este canal ($reason). Tente outro canal ou toque em ↻.", true)
        }
    }

    private fun showStatus(msg: String, err: Boolean = false) {
        statusTv.text = msg
        statusTv.setTextColor(if (err) 0xFFFF6B6B.toInt() else Color.WHITE)
        statusTv.visibility = View.VISIBLE
    }

    private fun hideStatus() {
        statusTv.visibility = View.GONE
    }

    // ---------- Tela cheia ----------

    private fun toggleFullscreen() {
        if (!fullscreen) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            setFullscreen(true)
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER
            setFullscreen(false)
        }
    }

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        listPanel.visibility = if (on) View.GONE else View.VISIBLE
        val lp = playerBox.layoutParams
        lp.height = if (on) ViewGroup.LayoutParams.MATCH_PARENT else (220 * resources.displayMetrics.density).toInt()
        playerBox.layoutParams = lp
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        setFullscreen(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE)
    }

    // ---------- Ciclo de vida ----------

    override fun onStart() {
        super.onStart()
        if (current != null) exo.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        exo.playWhenReady = false
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        exo.release()
        super.onDestroy()
    }
}
