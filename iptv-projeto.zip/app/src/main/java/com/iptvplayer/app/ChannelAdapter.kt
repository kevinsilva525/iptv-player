package com.iptvplayer.app

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class ChannelAdapter(
    private val onClick: (Channel) -> Unit,
    private val onLongClick: (Channel) -> Unit,
    private val isFav: (Channel) -> Boolean,
    private val isCurrent: (Channel) -> Boolean
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    private var items: List<Channel> = emptyList()

    fun submit(list: List<Channel>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val logo: ImageView = v.findViewById(R.id.logo)
        val name: TextView = v.findViewById(R.id.name)
        val group: TextView = v.findViewById(R.id.group)
        val star: TextView = v.findViewById(R.id.star)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        return VH(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val c = items[position]
        h.name.text = c.name
        h.group.text = c.group
        h.star.visibility = if (isFav(c)) View.VISIBLE else View.GONE
        h.itemView.setBackgroundColor(if (isCurrent(c)) 0xFF27406E.toInt() else Color.TRANSPARENT)
        if (c.logo.isNotEmpty()) h.logo.load(c.logo) else h.logo.setImageDrawable(null)
        h.itemView.setOnClickListener { onClick(c) }
        h.itemView.setOnLongClickListener {
            onLongClick(c)
            true
        }
    }
}
