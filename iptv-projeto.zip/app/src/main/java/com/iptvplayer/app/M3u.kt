package com.iptvplayer.app

data class Channel(
    val name: String,
    val logo: String,
    val group: String,
    val url: String,
    val userAgent: String?,
    val headers: Map<String, String>
) {
    val key: String get() = "$name|$url"
}

object M3u {
    private val attrRe = Regex("([\\w-]+)=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        var hasMeta = false
        var name = ""
        var logo = ""
        var group = "Sem grupo"

        for (raw in text.removePrefix("﻿").lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue

            if (line.startsWith("#EXTINF")) {
                val attrs = HashMap<String, String>()
                attrRe.findAll(line).forEach { attrs[it.groupValues[1].lowercase()] = it.groupValues[2] }
                val comma = line.lastIndexOf(',')
                var n = if (comma >= 0) line.substring(comma + 1).trim() else ""
                if (n.isEmpty()) n = attrs["tvg-name"] ?: "Sem nome"
                name = n
                logo = attrs["tvg-logo"] ?: ""
                val g = attrs["group-title"] ?: ""
                group = if (g.isBlank()) "Sem grupo" else g
                hasMeta = true
            } else if (line.startsWith("#EXTGRP:")) {
                val g = line.substring(8).trim()
                if (hasMeta && g.isNotEmpty()) group = g
            } else if (line.startsWith("#")) {
                continue
            } else {
                // Formato Kodi: url|User-Agent=xxx&Referer=yyy
                var url = line
                var ua: String? = null
                val headers = HashMap<String, String>()
                val bar = line.indexOf('|')
                if (bar > 0 && line.startsWith("http", ignoreCase = true)) {
                    url = line.substring(0, bar).trim()
                    line.substring(bar + 1).split('&').forEach { part ->
                        val eq = part.indexOf('=')
                        if (eq > 0) {
                            val k = part.substring(0, eq).trim()
                            val v = part.substring(eq + 1).trim()
                            if (k.equals("user-agent", ignoreCase = true)) ua = v else headers[k] = v
                        }
                    }
                }
                val finalName = if (hasMeta) name else (url.substringAfterLast('/').ifEmpty { "Canal" })
                val finalGroup = if (hasMeta) group else "Sem grupo"
                val finalLogo = if (hasMeta) logo else ""
                out.add(Channel(finalName, finalLogo, finalGroup, url, ua, headers))
                hasMeta = false
                name = ""
                logo = ""
                group = "Sem grupo"
            }
        }
        return out
    }
}
